﻿using BookStore_MVC.Models.Domain;
using BookStore_MVC.Repositories.Abstract;
using Microsoft.AspNetCore.Mvc;

namespace BookStore_MVC.Controllers
{
    public class PublisherController : Controller
    {
        private readonly IPublisherService service;
        public PublisherController(IPublisherService service)
        {
            this.service = service;      
        }
        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Add(Publisher model)
        {
            if (!ModelState.IsValid)
            {
              return View(model);
            }
            var result = service.Add(model);
            if (result)
            {
                TempData["msg"] = "Publisher added successfully"; 
                return RedirectToAction(nameof(Add));
            }
            TempData["msg"] = "An error occurred while adding the Publisher";
            return View(model);
        }
        [HttpGet]
        public IActionResult Update(int id)
        {
            var record = service.FindById(id);
            return View(record);
        }
        [HttpPost]
        public IActionResult Update(Publisher model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = service.Update(model);
            if (result)
            {
                TempData["upmsg"] = "Publisher Updated successfully";
                return RedirectToAction("GetAll");
            }
            TempData["upmsg"] = "An error occurred while Updating the Publisher";
            return View(model);
        }
        public IActionResult Delete(int  id)
        {
           
            var result = service.Delete(id);
            return RedirectToAction("GetAll");
        }
        public IActionResult GetAll()
        {

            var data = service.GetAll();
            return View(data);
        }
    }
}
