﻿using BookStore_MVC.Models.Domain;

namespace BookStore_MVC.Repositories.Abstract
{
    public interface IBookService
    {
        bool Add(Book model);
        bool Delete(int id);
        bool Update(Book model);
        Book FindById(int id);
        IEnumerable<Book> GetAll();
    }
}
