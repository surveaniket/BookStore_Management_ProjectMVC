﻿using BookStore_MVC.Models.Domain;

namespace BookStore_MVC.Repositories.Abstract
{
    public interface IAuthorService
    {
        bool Add(Author model);
        bool Delete(int id);
        bool Update(Author model);
        Author FindById(int id);
        IEnumerable<Author> GetAll();
    }
}
